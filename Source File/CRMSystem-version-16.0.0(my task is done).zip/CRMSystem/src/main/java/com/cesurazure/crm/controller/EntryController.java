package com.cesurazure.crm.controller;

import com.cesurazure.crm.model.AssignCRM;
import com.cesurazure.crm.model.Business;
import com.cesurazure.crm.model.CRMUser;
import com.cesurazure.crm.model.Contact;
import com.cesurazure.crm.model.Lead;
import com.cesurazure.crm.model.Task;
import com.cesurazure.crm.service.impl.IAssignCRMService;
import com.cesurazure.crm.service.impl.IAssignLeadService;
import com.cesurazure.crm.service.impl.IBusinessService;
import com.cesurazure.crm.service.impl.ICRMUserService;
import com.cesurazure.crm.service.impl.IContactService;
import com.cesurazure.crm.service.impl.ILeadService;
import com.cesurazure.crm.service.impl.ITaskService;
import com.google.gson.Gson;
import com.google.gson.GsonBuilder;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.MediaType;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RestController;
import org.springframework.web.servlet.ModelAndView;

@RestController
public class EntryController {

    @Autowired
    IBusinessService businessService;

    @Autowired
    ICRMUserService crmuserService;

    @Autowired
    ILeadService leadService;

    @Autowired
    IAssignCRMService assignCRMService;

    @Autowired
    IAssignLeadService assignLeadService;

    @Autowired
    ITaskService taskService;
    
    @Autowired
    IContactService contactService;

    @RequestMapping("/")
    public ModelAndView hello() {
        return new ModelAndView("entry/sign_in");
    }

    @RequestMapping(value = "/signup")
    public ModelAndView hello1() {
        return new ModelAndView("entry/sign_up");
    }

    @RequestMapping(value = "/home")
    public ModelAndView hello2() {
        return new ModelAndView("home/home_page");
    }

//    Activities
    @RequestMapping(value = "/activitiesview")
    public ModelAndView hello3() {
        Map<String, Object> map = new HashMap<String, Object>();
        List<Task> task = taskService.getAll();
        map.put("task", task);
        return new ModelAndView("activities/activities_view", "map", map);
    }

    @RequestMapping(value = "/taskcreate")
    public ModelAndView hello4() {
        List<CRMUser> crmlist = crmuserService.getAll();
        List<Lead> leadlist = leadService.getAll();

        Map<String, Object> map = new HashMap<String, Object>();
        map.put("crmlist", crmlist);
        map.put("leadlist", leadlist);
        return new ModelAndView("activities/task_create", "map", map);
    }

//    CRM
    @RequestMapping(value = "/crmusercreate")
    public ModelAndView hello5() {
        return new ModelAndView("crm/crm_user_create");
    }

    @RequestMapping(value = "/crmreport")
    public ModelAndView hello12() {
        List<CRMUser> crmlist = crmuserService.getAll();

        Map<String, Object> map = new HashMap<String, Object>();
        map.put("crmlist", crmlist);
        return new ModelAndView("crm/crm_report", "map", map);
    }

//    LEAD
    @RequestMapping(value = "/leadcreate")
    public ModelAndView hello6() {
        return new ModelAndView("lead/lead_create");
    }

    @RequestMapping(value = "/leadreport")
    public ModelAndView hello13() {
        List<Lead> leadlist = leadService.getAll();

        Map<String, Object> map = new HashMap<String, Object>();
        map.put("leadlist", leadlist);
        return new ModelAndView("lead/lead_report", "map", map);
    }

//    BUSINESS
    @RequestMapping(value = "/businesscreate")
    public ModelAndView hello7() {
        return new ModelAndView("business/business_create");
    }

    @RequestMapping(value = "/businessreport")
    public ModelAndView hello11() {
        List<Business> businessList = businessService.getAll();
        Map<String, Object> map = new HashMap<String, Object>();
        map.put("businessList", businessList);
        return new ModelAndView("business/business_report", "map", map);
    }

//    CONTACT
    @RequestMapping(value = "/contactcreate")
    public ModelAndView hello15() {
        return new ModelAndView("contact/contact_create");
    }
    
     @RequestMapping(value = "/contactreport")
    public ModelAndView hello16() {
        List<CRMUser> crmlist = crmuserService.getAll();
        List<Lead> leadlist = leadService.getAll();
        List<Contact> contactlist = contactService.getAll();
        Map<String, Object> map = new HashMap<String, Object>();
        map.put("crmlist", crmlist);
        map.put("leadlist", leadlist);
        map.put("contactlist", contactlist);
        return new ModelAndView("contact/contact_report", "map", map);
    }

//    ASSIGN
    @RequestMapping(value = "/assignCRM")
    public ModelAndView hello8() {
        List<CRMUser> crmlist = crmuserService.getAll();
        List<Business> businesslist = businessService.getAll();
        Map<String, Object> map = new HashMap<String, Object>();
        map.put("crmlist", crmlist);
        map.put("businesslist", businesslist);

        return new ModelAndView("assign/assign_crm", "map", map);
    }

    @RequestMapping(value = "/assignLead")
    public ModelAndView hello9() {
        List<CRMUser> crmlist = crmuserService.getAll();
        List<Business> businesslist = businessService.getAll();
        List<Lead> leadlist = leadService.getAll();
        Map<String, Object> map = new HashMap<String, Object>();
        map.put("crmlist", crmlist);
        map.put("businesslist", businesslist);
        map.put("leadlist", leadlist);

        return new ModelAndView("assign/assign_lead", "map", map);
    }

    @RequestMapping(value = "/assignreport")
    public ModelAndView hello14() {
        return new ModelAndView("assign/assign_report");
    }

    @RequestMapping(value = "/header")
    public ModelAndView hello10() {
        return new ModelAndView("common/header");
    }

}
