package com.cesurazure.crm.dao.impl;

import com.cesurazure.crm.common.ICommonDAO;
import com.cesurazure.crm.model.Business;

public interface IBusinessDAO extends ICommonDAO<Business> {

}
