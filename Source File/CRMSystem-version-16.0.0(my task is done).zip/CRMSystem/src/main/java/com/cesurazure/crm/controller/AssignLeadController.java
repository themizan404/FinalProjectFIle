package com.cesurazure.crm.controller;

import com.cesurazure.crm.controller.impl.IAssignLeadController;
import com.cesurazure.crm.model.AssignLead;
import com.cesurazure.crm.model.Lead;
import com.cesurazure.crm.service.impl.IAssignLeadService;
import com.cesurazure.crm.service.impl.IBusinessService;
import com.cesurazure.crm.service.impl.ICRMUserService;
import com.cesurazure.crm.service.impl.ILeadService;
import com.google.gson.Gson;
import com.google.gson.GsonBuilder;
import java.util.List;
import javax.servlet.http.HttpServletRequest;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.MediaType;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RestController;
import org.springframework.web.servlet.ModelAndView;

@RestController
public class AssignLeadController implements IAssignLeadController {

    @Autowired
    IAssignLeadService assignLeadService;

    @Autowired
    ILeadService leadService;

    @Autowired
    IBusinessService businessService;

    @Autowired
    ICRMUserService crmuserService;

    @Override
    @RequestMapping(value = "/assignLeadSave")
    public ModelAndView save(HttpServletRequest request) {
        System.out.println("*********** Hitted ***********");
        assignLeadService.save(request);
//         Work is not done here
        return new ModelAndView("redirect:/assignLead");
    }

    @Override
    public ModelAndView edit(int id) {
        throw new UnsupportedOperationException("Not supported yet."); //To change body of generated methods, choose Tools | Templates.
    }

    @Override
    public ModelAndView update(HttpServletRequest request) {
        throw new UnsupportedOperationException("Not supported yet."); //To change body of generated methods, choose Tools | Templates.
    }

    @Override
    public ModelAndView delete(int id) {
        throw new UnsupportedOperationException("Not supported yet."); //To change body of generated methods, choose Tools | Templates.
    }

    @Override
    public List<AssignLead> getAll() {
        throw new UnsupportedOperationException("Not supported yet."); //To change body of generated methods, choose Tools | Templates.
    }

//    To create Rest API
    @RequestMapping(value = "/getLead/{id}", method = RequestMethod.GET, produces = MediaType.APPLICATION_JSON_VALUE)
    public String getLead(@PathVariable("id") int id) {

        System.out.println("...................... " + id);
        GsonBuilder gson = new GsonBuilder();
        Gson g = gson.create();
        Lead lead = leadService.getById(id);
        return g.toJson(lead);
    }
}
