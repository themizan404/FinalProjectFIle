package com.cesurazure.crm.dao.impl;

import com.cesurazure.crm.common.ICommonDAO;
import com.cesurazure.crm.model.Lead;

public interface ILeadDAO extends ICommonDAO<Lead> {

}
