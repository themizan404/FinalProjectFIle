package com.cesurazure.crm.dao.impl;

import com.cesurazure.crm.common.ICommonDAO;
import com.cesurazure.crm.model.CRMUser;

public interface ICRMUserDAO extends ICommonDAO<CRMUser> {

}
