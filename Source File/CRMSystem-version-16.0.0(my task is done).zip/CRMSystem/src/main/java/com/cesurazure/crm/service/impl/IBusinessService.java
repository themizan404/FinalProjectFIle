package com.cesurazure.crm.service.impl;

import com.cesurazure.crm.common.ICommonService;
import com.cesurazure.crm.model.Business;

public interface IBusinessService extends ICommonService<Business> {

}
