package com.cesurazure.crm.dao;

import com.cesurazure.crm.dao.impl.IContactDAO;
import com.cesurazure.crm.model.Contact;
import java.util.List;
import org.hibernate.SessionFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Repository;
import org.springframework.transaction.annotation.Transactional;

@Repository(value = "contactDAO")
@Transactional
public class ContactDAO implements IContactDAO {

    @Autowired
    SessionFactory sessionFactory;

    @Override
    public Contact save(Contact t) {
        sessionFactory.getCurrentSession().save(t);
        sessionFactory.getCurrentSession().flush();
        return t;
    }

    @Override
    public Contact update(Contact t) {
        throw new UnsupportedOperationException("Not supported yet."); //To change body of generated methods, choose Tools | Templates.
    }

    @Override
    public Contact delete(int id) {
        throw new UnsupportedOperationException("Not supported yet."); //To change body of generated methods, choose Tools | Templates.
    }

    @Override
    public List<Contact> getAll() {
        List<Contact> contactList = sessionFactory.getCurrentSession().createCriteria(Contact.class).list();
        sessionFactory.getCurrentSession().flush();
        return contactList;
    }

    @Override
    public Contact getById(int id) {
        Contact contact = (Contact) sessionFactory.getCurrentSession().get(Contact.class, id);
        sessionFactory.getCurrentSession().flush();
        return contact;
    }

}
