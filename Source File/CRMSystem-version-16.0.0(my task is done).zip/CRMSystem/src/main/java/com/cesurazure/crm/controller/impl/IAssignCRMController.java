package com.cesurazure.crm.controller.impl;

import com.cesurazure.crm.common.ICommonController;
import com.cesurazure.crm.model.AssignCRM;

public interface IAssignCRMController extends ICommonController<AssignCRM> {

}
