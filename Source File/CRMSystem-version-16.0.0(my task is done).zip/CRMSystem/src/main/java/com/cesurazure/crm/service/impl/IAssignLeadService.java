/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package com.cesurazure.crm.service.impl;

import com.cesurazure.crm.common.ICommonService;
import com.cesurazure.crm.model.AssignLead;

/**
 *
 * @author Maria
 */
public interface IAssignLeadService extends ICommonService<AssignLead>{
    
}
