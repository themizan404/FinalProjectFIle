package com.cesurazure.crm.controller.impl;

import com.cesurazure.crm.common.ICommonController;
import com.cesurazure.crm.model.Task;

public interface ITaskController extends ICommonController<Task> {
    
}
