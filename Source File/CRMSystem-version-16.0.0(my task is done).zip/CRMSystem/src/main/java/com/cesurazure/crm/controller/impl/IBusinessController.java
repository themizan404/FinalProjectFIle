package com.cesurazure.crm.controller.impl;

import com.cesurazure.crm.common.ICommonController;
import com.cesurazure.crm.model.Business;

public interface IBusinessController extends ICommonController<Business> {

}
