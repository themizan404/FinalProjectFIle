package com.cesurazure.crm.controller;

import com.cesurazure.crm.controller.impl.IContactController;
import com.cesurazure.crm.model.Contact;
import com.cesurazure.crm.service.impl.ICRMUserService;
import com.cesurazure.crm.service.impl.IContactService;
import com.cesurazure.crm.service.impl.ILeadService;
import java.util.List;
import javax.servlet.http.HttpServletRequest;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;
import org.springframework.web.servlet.ModelAndView;

@RestController
public class ContactController implements IContactController {

    @Autowired
    IContactService contactService;

    @Autowired
    ILeadService leadService;

    @Autowired
    ICRMUserService crmuserService;

    @Override
    @RequestMapping(value = "/contactSave")
    public ModelAndView save(HttpServletRequest request) {
        System.out.println("*********** Hitted ***********");
        contactService.save(request);
        return new ModelAndView("redirect:/contactcreate");
    }

    @Override
    public ModelAndView edit(int id) {
        throw new UnsupportedOperationException("Not supported yet."); //To change body of generated methods, choose Tools | Templates.
    }

    @Override
    public ModelAndView update(HttpServletRequest request) {
        throw new UnsupportedOperationException("Not supported yet."); //To change body of generated methods, choose Tools | Templates.
    }

    @Override
    public ModelAndView delete(int id) {
        throw new UnsupportedOperationException("Not supported yet."); //To change body of generated methods, choose Tools | Templates.
    }

    @Override
    public List<Contact> getAll() {
        List<Contact> contactList = contactService.getAll();
        return contactList;
    }

}
