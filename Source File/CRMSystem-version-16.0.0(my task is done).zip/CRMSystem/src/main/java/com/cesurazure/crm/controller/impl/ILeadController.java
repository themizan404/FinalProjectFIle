package com.cesurazure.crm.controller.impl;

import com.cesurazure.crm.common.ICommonController;
import com.cesurazure.crm.model.Lead;

public interface ILeadController extends ICommonController<Lead> {

}
