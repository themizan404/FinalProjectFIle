package com.cesurazure.crm.service;

import com.cesurazure.crm.dao.impl.IContactDAO;
import com.cesurazure.crm.model.Contact;
import com.cesurazure.crm.service.impl.IContactService;
import java.util.List;
import javax.servlet.http.HttpServletRequest;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

@Service(value = "contactService")
public class ContactService implements IContactService {

    @Autowired
    IContactDAO contactDAO;

    @Override
    public Contact save(HttpServletRequest request) {
        Contact contact = new Contact();
        contact.setContactId(request.getParameter("contactId"));
        contact.setContactOwnerFirstName(request.getParameter("crmFirstName"));
        contact.setContactOwnerLastName(request.getParameter("crmLastName"));
        contact.setContactFirstName(request.getParameter("leadFirstName"));
        contact.setContactLastName(request.getParameter("leadLastName"));
        contact.setLeadSource(request.getParameter("leadSource"));
        contact.setContactIndustry(request.getParameter("leadIndustry"));
        contact.setContactCompany(request.getParameter("leadCompany"));
        contact.setContactJobTitle(request.getParameter("jobTitle"));
        contact.setContactDepartment(request.getParameter("contactDepartment"));
        contact.setContactEmail(request.getParameter("leadEmail"));
        contact.setContactMobile(request.getParameter("leadMobile"));
        contact.setContactFax(request.getParameter("leadFax"));
        contact.setContactWebsite(request.getParameter("leadWebsite"));
        contact.setContactDateOfBirth(request.getParameter("contactDateOfBirth"));
        contact.setReportingTo(request.getParameter("reportingTo"));
        contact.setBackupContact(request.getParameter("backupContact"));
        contact.setBackupContactEmail(request.getParameter("backupContactEmail"));
        contact.setBackupContactMobile(request.getParameter("backupContactMobile"));
//        ADDRESS
        contact.setContactStreet(request.getParameter("leadStreet"));
        contact.setContactCity(request.getParameter("leadCity"));
        contact.setContactState(request.getParameter("leadState"));
        contact.setContactZipCode(request.getParameter("leadZipCode"));
        contact.setContactCountry(request.getParameter("leadCountry"));
        contact.setContactDescription(request.getParameter("contactDescription"));
        
         System.out.println("*************" + contact.getContactFirstName());
         System.out.println("*************" + contact.getContactCompany());
         System.out.println("*************" + contact.getContactEmail());
         System.out.println("*************" + contact.getContactCountry());
        
        contactDAO.save(contact);
        return contact;
    }

    @Override
    public Contact update(HttpServletRequest request) {
        throw new UnsupportedOperationException("Not supported yet."); //To change body of generated methods, choose Tools | Templates.
    }

    @Override
    public Contact delete(int id) {
        throw new UnsupportedOperationException("Not supported yet."); //To change body of generated methods, choose Tools | Templates.
    }

    @Override
    public List<Contact> getAll() {
        return contactDAO.getAll();
    }

    @Override
    public Contact getById(int id) {
        return contactDAO.getById(id);
    }

}
