package com.cesurazure.crm.service.impl;

import com.cesurazure.crm.common.ICommonService;
import com.cesurazure.crm.model.Contact;

public interface IContactService extends ICommonService<Contact> {

}
