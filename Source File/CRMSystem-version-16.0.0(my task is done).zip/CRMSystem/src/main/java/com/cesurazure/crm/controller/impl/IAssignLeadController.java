/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package com.cesurazure.crm.controller.impl;

import com.cesurazure.crm.common.ICommonController;
import com.cesurazure.crm.model.AssignLead;

/**
 *
 * @author Maria
 */
public interface IAssignLeadController extends ICommonController<AssignLead>{
    
}
