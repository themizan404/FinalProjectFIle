package com.cesurazure.crm.controller.impl;

import com.cesurazure.crm.common.ICommonController;
import com.cesurazure.crm.model.CRMUser;

public interface ICRMUserController extends ICommonController<CRMUser> {

}
