package com.cesurazure.crm.model;

import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.Table;

@Entity(name = "contact")
@Table(name = "contact")
public class Contact {

    @Id
    private int id;
    private String contactId;
    private String contactOwnerFirstName;
    private String contactOwnerLastName;
    private String contactFirstName;
    private String contactLastName;
    private String leadSource;
    private String contactIndustry;
    private String contactCompany;
    private String contactJobTitle;
    private String contactDepartment;
    private String contactEmail;
    private String contactMobile;
    private String contactFax;
    private String contactWebsite;
    private String contactDateOfBirth;
    private String reportingTo;
    private String backupContact;
    private String backupContactEmail;
    private String backupContactMobile;
    private String contactStreet;
    private String contactCity;
    private String contactState;
    private String contactZipCode;
    private String contactCountry;
    private String contactDescription;

    public int getId() {
        return id;
    }

    public void setId(int id) {
        this.id = id;
    }

    public String getContactId() {
        return contactId;
    }

    public void setContactId(String contactId) {
        this.contactId = contactId;
    }

    public String getContactOwnerFirstName() {
        return contactOwnerFirstName;
    }

    public void setContactOwnerFirstName(String contactOwnerFirstName) {
        this.contactOwnerFirstName = contactOwnerFirstName;
    }

    public String getContactOwnerLastName() {
        return contactOwnerLastName;
    }

    public void setContactOwnerLastName(String contactOwnerLastName) {
        this.contactOwnerLastName = contactOwnerLastName;
    }

    public String getContactFirstName() {
        return contactFirstName;
    }

    public void setContactFirstName(String contactFirstName) {
        this.contactFirstName = contactFirstName;
    }

    public String getContactLastName() {
        return contactLastName;
    }

    public void setContactLastName(String contactLastName) {
        this.contactLastName = contactLastName;
    }

    public String getLeadSource() {
        return leadSource;
    }

    public void setLeadSource(String leadSource) {
        this.leadSource = leadSource;
    }

    public String getContactIndustry() {
        return contactIndustry;
    }

    public void setContactIndustry(String contactIndustry) {
        this.contactIndustry = contactIndustry;
    }

    public String getContactCompany() {
        return contactCompany;
    }

    public void setContactCompany(String contactCompany) {
        this.contactCompany = contactCompany;
    }

    public String getContactJobTitle() {
        return contactJobTitle;
    }

    public void setContactJobTitle(String contactJobTitle) {
        this.contactJobTitle = contactJobTitle;
    }

    public String getContactDepartment() {
        return contactDepartment;
    }

    public void setContactDepartment(String contactDepartment) {
        this.contactDepartment = contactDepartment;
    }

    public String getContactEmail() {
        return contactEmail;
    }

    public void setContactEmail(String contactEmail) {
        this.contactEmail = contactEmail;
    }

    public String getContactMobile() {
        return contactMobile;
    }

    public void setContactMobile(String contactMobile) {
        this.contactMobile = contactMobile;
    }

    public String getContactFax() {
        return contactFax;
    }

    public void setContactFax(String contactFax) {
        this.contactFax = contactFax;
    }

    public String getContactWebsite() {
        return contactWebsite;
    }

    public void setContactWebsite(String contactWebsite) {
        this.contactWebsite = contactWebsite;
    }

    public String getContactDateOfBirth() {
        return contactDateOfBirth;
    }

    public void setContactDateOfBirth(String contactDateOfBirth) {
        this.contactDateOfBirth = contactDateOfBirth;
    }

    public String getReportingTo() {
        return reportingTo;
    }

    public void setReportingTo(String reportingTo) {
        this.reportingTo = reportingTo;
    }

    public String getBackupContact() {
        return backupContact;
    }

    public void setBackupContact(String backupContact) {
        this.backupContact = backupContact;
    }

    public String getBackupContactEmail() {
        return backupContactEmail;
    }

    public void setBackupContactEmail(String backupContactEmail) {
        this.backupContactEmail = backupContactEmail;
    }

    public String getBackupContactMobile() {
        return backupContactMobile;
    }

    public void setBackupContactMobile(String backupContactMobile) {
        this.backupContactMobile = backupContactMobile;
    }

    public String getContactStreet() {
        return contactStreet;
    }

    public void setContactStreet(String contactStreet) {
        this.contactStreet = contactStreet;
    }

    public String getContactCity() {
        return contactCity;
    }

    public void setContactCity(String contactCity) {
        this.contactCity = contactCity;
    }

    public String getContactState() {
        return contactState;
    }

    public void setContactState(String contactState) {
        this.contactState = contactState;
    }

    public String getContactZipCode() {
        return contactZipCode;
    }

    public void setContactZipCode(String contactZipCode) {
        this.contactZipCode = contactZipCode;
    }

    public String getContactCountry() {
        return contactCountry;
    }

    public void setContactCountry(String contactCountry) {
        this.contactCountry = contactCountry;
    }

    public String getContactDescription() {
        return contactDescription;
    }

    public void setContactDescription(String contactDescription) {
        this.contactDescription = contactDescription;
    }

}
