package com.cesurazure.crm.service.impl;

import com.cesurazure.crm.common.ICommonService;
import com.cesurazure.crm.model.Task;

public interface ITaskService extends ICommonService<Task> {

}
