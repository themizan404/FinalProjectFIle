package com.cesurazure.crm.controller.impl;

import com.cesurazure.crm.common.ICommonController;
import com.cesurazure.crm.model.Contact;

public interface IContactController extends ICommonController<Contact> {

}
