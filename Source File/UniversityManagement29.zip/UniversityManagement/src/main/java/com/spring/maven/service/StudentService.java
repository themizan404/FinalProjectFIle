/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package com.spring.maven.service;

import com.spring.maven.dao.impl.IStudentDAO;
import com.spring.maven.model.Student;

import com.spring.maven.service.impl.IStudentService;
import java.util.List;
import java.util.Map;
import javax.servlet.http.HttpServletRequest;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

/**
 *
 * @author sany5
 */
@Service(value = "studentService")
public class StudentService implements IStudentService{
   @Autowired
   IStudentDAO studentDAO;

    @Override
    public Student save(HttpServletRequest request) {
       
       Student s = new Student();
       s.setSid(Integer.parseInt(request.getParameter("sid")));
       s.setName(request.getParameter("name"));
       s.setEmail(request.getParameter("email"));
       s.setPhone(request.getParameter("phone"));
       s.setAddress(request.getParameter("address"));
       s.setfName(request.getParameter("fname"));
       s.setmName(request.getParameter("mname"));
       s.setDob(request.getParameter("dob"));
       s.setReligion(request.getParameter("religion"));
       s.setBloodGroup(request.getParameter("bloodgroup"));
       s.setGender(request.getParameter("gender"));
       studentDAO.save(s);
       return s;
    }

    @Override
    public Student update(HttpServletRequest request) {
       Student s = new Student();
       s.setId(Integer.parseInt(request.getParameter("id")));
       s.setSid(Integer.parseInt(request.getParameter("sid")));
       s.setName(request.getParameter("name"));
       s.setEmail(request.getParameter("email"));
       s.setPhone(request.getParameter("phone"));
       s.setAddress(request.getParameter("address"));
       s.setfName(request.getParameter("fname"));
       s.setmName(request.getParameter("mname"));
       s.setDob(request.getParameter("dob"));
       s.setReligion(request.getParameter("religion"));
       s.setBloodGroup(request.getParameter("bloodgroup"));
       s.setGender(request.getParameter("gender"));
       studentDAO.update(s);
       return s;
    }

    @Override
    public Student delete(int id) {
        return studentDAO.delete(id);
    }

    @Override
    public List<Student> getAll() {
        return studentDAO.getAll();
    }

    @Override
    public Student getById(int id) {
       return studentDAO.getById(id);
    }
   
   
}
