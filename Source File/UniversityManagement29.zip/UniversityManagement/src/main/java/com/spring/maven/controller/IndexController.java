/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package com.spring.maven.controller;

import com.google.gson.Gson;
import com.google.gson.GsonBuilder;
import com.spring.maven.model.AssignFacultyCourse;
import com.spring.maven.model.AssignStudentCourse;
import com.spring.maven.model.Attendance;
import com.spring.maven.model.Book;
import com.spring.maven.model.Course;
import com.spring.maven.model.Department;
import com.spring.maven.model.Faculty;
import com.spring.maven.model.Marks;
import com.spring.maven.model.Notice;
import com.spring.maven.model.Result;
import com.spring.maven.model.Semester;
import com.spring.maven.model.Student;
import com.spring.maven.model.University;
import com.spring.maven.service.AssignStudentCourseService;
import com.spring.maven.service.impl.IAssignFacultyCourseService;
import com.spring.maven.service.impl.IAssignStudentCourseService;
import com.spring.maven.service.impl.IAttendanceService;
import com.spring.maven.service.impl.IBookService;
import com.spring.maven.service.impl.ICourseService;
import com.spring.maven.service.impl.IDepartmentService;
import com.spring.maven.service.impl.IFacultyService;
import com.spring.maven.service.impl.IMarksService;
import com.spring.maven.service.impl.INoticeService;
import com.spring.maven.service.impl.IResultService;
import com.spring.maven.service.impl.ISemesterService;
import com.spring.maven.service.impl.IStudentService;
import com.spring.maven.service.impl.IUniversityService;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import javax.servlet.http.HttpServletRequest;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.MediaType;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RestController;
import org.springframework.web.servlet.ModelAndView;

/**
 *
 * @author B13
 */
@RestController
public class IndexController {

    @Autowired
    IUniversityService universityService;

    @Autowired
    IDepartmentService departmentService;

    @Autowired
    IStudentService studentService;

    @Autowired
    IFacultyService facultyService;

    @Autowired
    ISemesterService semesterService;

    @Autowired
    ICourseService courseService;

    @Autowired
    IAssignStudentCourseService assignStudentCourseService;
    
    @Autowired
    AssignStudentCourseService assignStudentCourseService2;

    @Autowired
    IAssignFacultyCourseService assignFacultyCourseService;
    
    @Autowired
    IAttendanceService attendanceService;
    
    @Autowired
    IResultService resultService;
    
    @Autowired
    IMarksService marksService;
    
    @Autowired
    INoticeService noticeService;
    
    @Autowired
    IBookService bookService;

    @RequestMapping("/")
    public ModelAndView index() {
        return new ModelAndView("index");
    }

    @RequestMapping("/login")
    public ModelAndView login() {
        return new ModelAndView("/admin/login");
    }

    @RequestMapping("/admin")
    public ModelAndView adminDashBoard(HttpServletRequest request) {

        return new ModelAndView("/admin/university");
    }

    @RequestMapping("/department")
    public ModelAndView department() {
        List<University> uList = universityService.getAll();

        Map<String, Object> map = new HashMap<String, Object>();
        map.put("uList", uList);

        return new ModelAndView("/admin/department", "map", map);
    }

    @RequestMapping("/semister")
    public ModelAndView semister() {

        List<University> uList = universityService.getAll();

        Map<String, Object> map = new HashMap<String, Object>();
        map.put("uList", uList);

        return new ModelAndView("/admin/semister", "map", map);

    }

    @RequestMapping("/courses")
    public ModelAndView courses() {
        List<Department> departments = departmentService.getAll();
        Map<String, Object> map = new HashMap<String, Object>();
        map.put("departments", departments);
        return new ModelAndView("/admin/courses", "map", map);
    }

    @RequestMapping("/students")
    public ModelAndView students() {
        return new ModelAndView("/admin/students");
    }

    @RequestMapping("/faculty")
    public ModelAndView faculty() {
        return new ModelAndView("/admin/faculty");
    }

    @RequestMapping("/library")
    public ModelAndView library() {
        return new ModelAndView("/admin/library");
    }

    @RequestMapping("/notice")
    public ModelAndView notice() {
        List<Notice> notice=noticeService.getAll();
         Map<String, Object> map = new HashMap<String, Object>();
         map.put("notice", notice);
        return new ModelAndView("/admin/notice","map",map);
    }

    @RequestMapping("/assignCourse")
    public ModelAndView assignCourse() {
        List<Student> students = studentService.getAll();
        List<Semester> semesters = semesterService.getAll();
        List<Course> courses = courseService.getAll();
        List<Faculty> facultys = facultyService.getAll();
        Map<String, Object> map = new HashMap<String, Object>();

        map.put("students", students);
        map.put("semesters", semesters);
        map.put("courses", courses);
        map.put("facultys", facultys);
        return new ModelAndView("/admin/assign_course", "map", map);
    }
    
    @RequestMapping("/reports")
    public ModelAndView reports() {
        
        List<Student> s = studentService.getAll();
        List<Faculty> f = facultyService.getAll();
        List<Attendance> attendances = attendanceService.getAll();
        
        Map<String, Object> map=new HashMap<String, Object>();
        map.put("students", s);
        map.put("faculties", f);
        map.put("attendances", attendances);
        return new ModelAndView("/admin/report","map",map);
    }

    //Faculty 
    @RequestMapping("/fLogin")
    public ModelAndView fLogin() {
        return new ModelAndView("/faculty/f_login");
    }

    @RequestMapping("/fStudent")
    public ModelAndView fStudent() {
        return new ModelAndView("/faculty/f_students");
    }

    @RequestMapping("/fNotice")
    public ModelAndView fNotice() {
         List<Notice> notice=noticeService.getAllByFacultyPrivilege();
         Map<String, Object> map = new HashMap<String, Object>();
         map.put("notice", notice);
        return new ModelAndView("/faculty/f_notice", "map",map);
    }

    @RequestMapping("/fInfo")
    public ModelAndView fInfo() {
        return new ModelAndView("/faculty/f_info");
    }
    //Result Making Start

    @RequestMapping("/fResult")
    public ModelAndView fResult() {
        List<Course> courses = courseService.getAll();
        List<Semester> semesters = semesterService.getAll();
        
        Map<String, Object> map = new HashMap<String, Object>();
        map.put("courses", courses);
        map.put("semesters", semesters);
        return new ModelAndView("/faculty/f_result", "map", map);
    }

    
    
    ////////Query////////
    @RequestMapping(value = "/createResult")
    public ModelAndView createResult(HttpServletRequest request) {

        
        String courseName = request.getParameter("courseName");
        String semesterName = request.getParameter("semesterName");

        List<AssignStudentCourse> asc = assignStudentCourseService2.getAllbyCourse(courseName,semesterName);
        List<Course> courses = courseService.getAll();
        List<Semester> semesters = semesterService.getAll();
        List<Faculty> f = facultyService.getAll();
        Map<String, Object> map = new HashMap<String, Object>();
        map.put("asc", asc);
        map.put("courses", courses);
        map.put("semesters", semesters);
        map.put("semesters", semesters);
        map.put("facultys", f);
        return new ModelAndView("/faculty/f_create_result", "map", map);

    }
    
    @RequestMapping("/resultProcess")
    public ModelAndView resultProcess() {
        List<Result> results=resultService.getAll();
        List<Marks> marks=marksService.getAll();
        Map<String, Object> map = new HashMap<String, Object>();
        map.put("results", results);
        map.put("marks", marks);
        
        return new ModelAndView("/faculty/result_process","map",map);
    }
    
    ////////Query////////
    @RequestMapping(value = "/createAttendance")
    public ModelAndView createAttendance(HttpServletRequest request) {

        List<Course> courses = courseService.getAll();
        List<Faculty> facultys = facultyService.getAll();
        String courseName = request.getParameter("courseName");
        String semesterName = request.getParameter("semesterName");

        List<AssignStudentCourse> asc = assignStudentCourseService2.getAllbyCourse(courseName,semesterName);
        Map<String, Object> map = new HashMap<String, Object>();
        map.put("asc", asc);
        map.put("courses", courses);
        map.put("facultys", facultys);

        return new ModelAndView("/faculty/f_create_attendance", "map", map);

    }
    
    
    
    

    //Result Making end
    //Attendance Making Start
    @RequestMapping("/fAttendance")
    public ModelAndView fAttendance() {
        List<Course> courses = courseService.getAll();
        List<Semester> semesters = semesterService.getAll();
        Map<String, Object> map = new HashMap<String, Object>();
        map.put("courses", courses);
        map.put("semesters", semesters);

        return new ModelAndView("/faculty/f_attendanceMain", "map", map);
    }

    // for Student
    @RequestMapping("/sLogin")
    public ModelAndView sLogin() {
        return new ModelAndView("/student/s_login");
    }
    
    //Student Login Through Id
    
    
    
    
    @RequestMapping("/sInfo")
    public ModelAndView sInfo(HttpServletRequest request) {
//        int id= Integer.parseInt(request.getParameter("password"));
//        AssignStudentCourse asc=assignStudentCourseService.getById(id);
//        System.out.println(asc.getName());
        
        List<Notice> notice=noticeService.getAllByStudentPrivilege();
         Map<String, Object> map = new HashMap<String, Object>();
         map.put("notice", notice);
         //map.put("asc", asc);
        return new ModelAndView("/student/s_info","map",map);
    }

    @RequestMapping("/sLibrary")
    public ModelAndView sLibrary() {
        List<Book> books=bookService.getAll();
         Map<String, Object> map = new HashMap<String, Object>();
         map.put("books", books);
        return new ModelAndView("/student/s_library","map",map);
    }

    @RequestMapping("/sNotice")
    public ModelAndView sNotice() {
        List<Notice> notice=noticeService.getAllByStudentPrivilege();
         Map<String, Object> map = new HashMap<String, Object>();
         map.put("notice", notice);
        return new ModelAndView("/student/s_notice", "map",map);
        
    }

    @RequestMapping("/sResult")
    public ModelAndView sResult() {
        return new ModelAndView("/student/s_result");
    }

    @RequestMapping("/sAttendance")
    public ModelAndView sAttendance() {
        return new ModelAndView("/student/s_attendance");
    }

    @RequestMapping(value = "/getUniversity/{id}", method = RequestMethod.GET, produces = MediaType.APPLICATION_JSON_VALUE)
    public String getAllUniversity(@PathVariable("id") int id) {

        System.out.println("...................... " + id);
        GsonBuilder gson = new GsonBuilder();
        Gson g = gson.create();
        University u = universityService.getById(id);
        return g.toJson(u);
    }

    @RequestMapping(value = "/getAllAssignStudent/{id}", method = RequestMethod.GET, produces = MediaType.APPLICATION_JSON_VALUE)
    public String getAllAssignStudent(@PathVariable("id") int id) {

        System.out.println("...................... " + id);
        GsonBuilder gson = new GsonBuilder();
        Gson g = gson.create();
        AssignStudentCourse asc = assignStudentCourseService.getById(id);
        return g.toJson(asc);
    }

    @RequestMapping(value = "/getAllAssignFaculty/{id}", method = RequestMethod.GET, produces = MediaType.APPLICATION_JSON_VALUE)
    public String getAllAssignFaculty(@PathVariable("id") int id) {

        System.out.println("...................... " + id);
        GsonBuilder gson = new GsonBuilder();
        Gson g = gson.create();
        AssignFacultyCourse afc = assignFacultyCourseService.getById(id);
        return g.toJson(afc);
    }
    
    

}
